# PropBooks — Deployment Guide

This walks you through getting PropBooks from a fresh repository to a live, secured production site on Vercel + Supabase.

**Time required:** 2–4 hours for first deployment, 30 min for subsequent ones.

**Prerequisites:**
- A GitHub account
- A Vercel account (free Hobby plan is fine to start)
- A Supabase account (free tier works; upgrade to Pro before real traffic)
- Node.js 20+ locally
- A domain name (optional but recommended for production)

---

## Phase 1 — Local setup

### 1.1 Clone and install

```bash
git clone <your-repo-url> propbooks
cd propbooks
npm install
cp .env.example .env.local
```

### 1.2 Create a Supabase project

1. Go to https://app.supabase.com → **New project**
2. Pick a region close to your users (Frankfurt `eu-central-1` is good for East Africa)
3. Set a strong database password — save it in a password manager
4. Wait ~2 minutes for provisioning

### 1.3 Capture your Supabase keys

In the Supabase dashboard → **Settings → API**, copy:
- `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
- `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `service_role secret` key → `SUPABASE_SERVICE_ROLE_KEY` ⚠️ **Treat like a database password. Never commit. Never put in a Client Component.**

In **Settings → Database → Connection string → URI**, copy → `DATABASE_URL`

Paste all four into your `.env.local`.

### 1.4 Run migrations

Install the Supabase CLI:

```bash
npm install -g supabase
supabase login
supabase link --project-ref <your-project-ref>
```

Push the migrations:

```bash
supabase db push
```

This creates all tables, RLS policies, helper functions, and audit log.

### 1.5 Generate TypeScript types from your real schema

```bash
npx supabase gen types typescript --linked > lib/supabase/database.types.ts
```

This replaces the placeholder with strict types — TypeScript will now catch table/column typos at compile time.

### 1.6 Run locally

```bash
npm run dev
```

Visit http://localhost:3000. You should be redirected to `/login`. Click **Create an account** and sign up with a real email (Supabase will require email confirmation by default — check your inbox).

---

## Phase 2 — OAuth providers (Google, Microsoft, Apple)

In **Supabase Dashboard → Authentication → Providers**:

### Google
1. Create OAuth credentials at https://console.cloud.google.com/apis/credentials
2. **Authorized redirect URIs:** `https://<your-project>.supabase.co/auth/v1/callback`
3. Paste Client ID + Secret into Supabase Google provider, **Save**

### Microsoft (Azure)
1. Register an app at https://portal.azure.com → Azure AD → App registrations
2. **Redirect URI** (web): `https://<your-project>.supabase.co/auth/v1/callback`
3. Paste Application (client) ID + a generated secret into Supabase Azure provider

### Apple
1. Apple Developer → Certificates, Identifiers & Profiles → register a Service ID
2. Configure **Sign in with Apple** → set return URL to `https://<your-project>.supabase.co/auth/v1/callback`
3. Generate a private key (`.p8` file) — keep it secure
4. Paste Service ID, Team ID, Key ID, and key contents into Supabase Apple provider

> The current login form is email/password only. Adding social sign-in buttons takes ~10 lines of `signInWithOAuth({ provider: 'google' })` calls. See `app/(auth)/login/page.tsx`.

---

## Phase 3 — Stripe (for subscriptions)

### 3.1 Create products + prices

1. https://dashboard.stripe.com → **Products** → create one for each plan: Starter, Growth, Professional, Enterprise
2. For each product, add a **monthly** and **yearly** price
3. Copy each `price_xxx` ID into the corresponding `STRIPE_PRICE_*` env var

### 3.2 Get your keys

In **Stripe → Developers → API keys**:
- `Publishable key` (`pk_test_...` / `pk_live_...`) → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
- `Secret key` (`sk_test_...` / `sk_live_...`) → `STRIPE_SECRET_KEY`

### 3.3 Webhook (after Vercel deploy)

You'll come back to this in Phase 5.

---

## Phase 4 — Rate limiting (Upstash Redis)

1. https://console.upstash.com → **Create Database** (pick same region as your Vercel project)
2. Copy `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` into env

If you skip this step the app still runs, but rate limiting becomes a no-op — **do not skip for production**.

---

## Phase 5 — Deploy to Vercel

### 5.1 Push to GitHub

```bash
git add .
git commit -m "Initial PropBooks scaffold"
git push origin main
```

### 5.2 Import to Vercel

1. https://vercel.com/new → import your GitHub repo
2. Framework: **Next.js** (auto-detected)
3. **Do not deploy yet** — click **Environment Variables**

### 5.3 Add environment variables

For **every** variable in `.env.example`, add it under **all three scopes** (Production / Preview / Development) unless you specifically want different values per environment.

⚠️ **Pitfalls:**
- `NEXT_PUBLIC_*` vars are **inlined at build time**. If you change them you must redeploy.
- `SUPABASE_SERVICE_ROLE_KEY` and `STRIPE_SECRET_KEY` are **NOT** prefixed with `NEXT_PUBLIC_` — they stay server-only. If you accidentally rename one with the public prefix you've leaked it to every browser.
- Set `NEXT_PUBLIC_APP_URL` to your eventual production URL (e.g. `https://app.propbooks.io`). For the first deploy, use the auto-assigned `https://propbooks-xxx.vercel.app` and update later.

### 5.4 Deploy

Click **Deploy**. First build takes 2–4 min. If it fails, check the build log — usually a missing env var.

### 5.5 Configure Stripe webhook

1. Stripe → **Developers → Webhooks → Add endpoint**
2. Endpoint URL: `https://<your-vercel-domain>/api/webhooks/stripe`
3. Events to listen for:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
4. Copy the **Signing secret** (`whsec_...`) into Vercel env as `STRIPE_WEBHOOK_SECRET`
5. Redeploy

### 5.6 Configure Supabase auth redirects

In **Supabase → Authentication → URL Configuration**:
- **Site URL:** `https://<your-vercel-domain>`
- **Redirect URLs:** add both:
  - `https://<your-vercel-domain>/callback`
  - `https://*-<your-team>.vercel.app/callback` (wildcard for previews — required if you want auth working on PR previews)

---

## Phase 6 — Custom domain

1. Vercel project → **Settings → Domains** → add `app.propbooks.io`
2. Update your DNS as Vercel instructs (CNAME or A record)
3. Vercel auto-provisions a Let's Encrypt certificate
4. Update `NEXT_PUBLIC_APP_URL` env var to the new domain
5. Update Supabase **Site URL** and **Redirect URLs** to the new domain
6. Update Stripe webhook URL to the new domain

---

## Phase 7 — Pre-launch checklist

Before letting real users in:

- [ ] All env vars set in Vercel for **Production** scope
- [ ] Supabase **Authentication → Email** → confirm email enabled
- [ ] Supabase **Authentication → Settings** → minimum password length set to **12**
- [ ] Supabase **Database → Backups** → daily backups enabled (Pro plan)
- [ ] Supabase **Project → API** → service role key is NOT in any `NEXT_PUBLIC_*` var
- [ ] Test signup → confirm email → login → create org → invite user → log out → log back in
- [ ] Test that creating an invoice as User A in Org A is invisible to User B in Org B (RLS sanity check)
- [ ] Run `npm run audit` — no high/critical CVEs
- [ ] Stripe webhook fires successfully on a test subscription (use Stripe CLI: `stripe listen --forward-to ...`)
- [ ] CSP doesn't block any legitimate resource (check browser console on every page)
- [ ] HTTPS-only — visit `http://...` and verify it redirects
- [ ] `https://hstspreload.org/?domain=yourdomain.com` — submit for HSTS preload after a week of stable HTTPS
- [ ] Run https://securityheaders.com against your domain — should grade **A** or better
- [ ] Run https://observatory.mozilla.org against your domain — should grade **A** or better
- [ ] Set up uptime monitoring (Better Uptime, UptimeRobot, or Vercel's built-in)
- [ ] Set up error tracking (Sentry recommended)
- [ ] Document your incident response plan: who gets paged, how to revoke a leaked key, how to restore from backup
- [ ] **Most important:** have someone who isn't you do a security review

---

## Phase 8 — Day-2 operations

### Rotating the service role key
If you suspect a leak: Supabase Dashboard → **Settings → API → Reset service role key** → update Vercel env → redeploy. This invalidates the old key immediately.

### Database migrations
Always create a new migration file (`supabase/migrations/000N_description.sql`) — never edit existing ones. Test locally with `supabase db reset` before pushing.

### Backups and restores
Supabase Pro takes daily backups automatically. Test a restore to a staging project quarterly so you actually know the procedure works when you need it.

### Monitoring RLS bypasses
Periodically run this query as service role to look for tables without RLS:
```sql
select schemaname, tablename, rowsecurity
  from pg_tables where schemaname = 'public' and rowsecurity = false;
```
The result should be empty.

### Compliance reminder (Kenya)
Tenant data falls under the **Data Protection Act 2019**. You'll need:
- A Data Protection Officer (or designated contact) registered with the **Office of the Data Protection Commissioner**
- A privacy notice on your site
- A data processing agreement with Supabase (they have a standard DPA)
- Process for handling data subject access requests
- Breach notification procedure (72 hours to ODPC)

This is not optional and not legal advice. Talk to a Kenyan privacy lawyer before going live.
