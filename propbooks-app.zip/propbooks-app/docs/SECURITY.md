# PropBooks — Security Model

This document is the source of truth for how PropBooks is secured. Anyone who modifies the codebase should read it first.

---

## 1. Threat model

We assume an attacker who:
- Can sign up for a normal user account
- Can read the entire frontend bundle (it's public)
- Can intercept and replay HTTP traffic (we use HTTPS to defeat this)
- May be a logged-in user trying to read another organization's data
- May be a curious employee of a customer trying to read data they shouldn't
- May POST forged webhook requests to our public endpoints

We do NOT defend against:
- A nation-state attacker with zero-day exploits in Vercel/Supabase
- An attacker who has compromised the developer's laptop or GitHub account
- Physical access to our infrastructure

---

## 2. Defence in depth

Each layer is designed to fail safely if the layer above is bypassed.

### Layer 1 — Network
- Vercel terminates TLS, redirects HTTP→HTTPS
- HSTS header forces HTTPS for 2 years (preload-eligible)
- Strict CSP with per-request nonce blocks injected scripts
- All other security headers (X-Frame-Options, X-Content-Type-Options, etc.) set in `next.config.mjs`

### Layer 2 — Authentication
- Supabase Auth handles password hashing (bcrypt), email verification, session management
- Session tokens stored as httpOnly, secure, sameSite=lax cookies — JavaScript cannot read them
- Cookies refreshed by middleware on every request
- Sign-in rate-limited to 5 attempts/minute/IP+email pair
- Sign-up rate-limited to 3/hour/IP
- Generic error messages — never reveal whether an email is registered

### Layer 3 — Authorization (the critical layer)
**Postgres Row-Level Security is the ONLY thing keeping organizations from reading each other's data.** App-level checks are defense in depth, not the primary control.

Every query made with the user's JWT (via `createClient()` server or browser) runs through RLS. Even if a developer writes a query like `from('invoices').select('*')` with no filter, Postgres only returns rows where `organization_id = ANY(user_orgs())`.

The only way to bypass RLS is the `service_role` key, which lives in `SUPABASE_SERVICE_ROLE_KEY` and is used by `createAdminClient()`. That client:
- Throws an error if called in the browser (`typeof window !== 'undefined'`)
- Is restricted to webhook handlers and explicit admin operations
- Each call site is required to do its own authorization check first

### Layer 4 — Input validation
Every Server Action and Route Handler parses input through a Zod schema before doing anything. Schemas are in `lib/validation/schemas.ts`. Malformed input gets a generic error — no stack traces leaked to clients.

### Layer 5 — Output safety
- React escapes HTML by default — XSS via rendered content requires `dangerouslySetInnerHTML`
- We do NOT use `dangerouslySetInnerHTML` anywhere in user-facing rendering
- Any future use of it (e.g., rendering email previews) MUST sanitize through `isomorphic-dompurify`
- File uploads (when added) must enforce content-type allowlist + virus scan

### Layer 6 — Audit
Sensitive mutations write to `audit_log`. The table is append-only (revoked update/delete from app roles) and admin-only readable. Includes IP, user agent, actor, action, resource, and a JSON diff.

---

## 3. Sensitive operations checklist

Before merging any PR that introduces a Server Action or Route Handler:

- [ ] First line is `'use server'` (Server Action) or appropriate `runtime` (Route Handler)
- [ ] First call inside is `requireUser()` (or webhook signature verification for unauthenticated endpoints)
- [ ] Input parsed through a Zod schema before use
- [ ] `requireRole()` or `assertCanAccessProperty()` called before mutating
- [ ] Rate limiter applied (`writeLimiter` for mutations)
- [ ] Money math uses `Decimal` from `lib/security/money.ts` — never raw `Number`
- [ ] Audit log entry written after success
- [ ] `revalidatePath()` called for affected routes
- [ ] No PII or secrets logged
- [ ] No `service_role` client used unless explicitly justified in PR description

---

## 4. Secret management

### Where secrets live
- Local dev: `.env.local` (in `.gitignore`)
- Vercel: project Environment Variables, scoped to Production / Preview / Development
- Supabase: managed by Supabase, never visible to us in plain text after creation

### Never commit
The following must never appear in git history. If you accidentally commit one:
1. Rotate it immediately (Supabase / Stripe / Upstash dashboards all have a "regenerate" button)
2. Force-push removal (or rewrite history)
3. Assume the old value is compromised

### Rotation cadence
- `SUPABASE_SERVICE_ROLE_KEY`: rotate annually, or immediately on any suspicion of leak
- `STRIPE_SECRET_KEY`: rotate annually
- `STRIPE_WEBHOOK_SECRET`: rotate when rotating endpoint, or annually
- `APP_SECRET`: rotate every 6 months
- Database password: rotate annually

---

## 5. Common mistakes to avoid

### "I'll just disable RLS for this query, it's faster"
No. RLS is the foundation of multi-tenant isolation. Use the service role with explicit auth checks if you genuinely need to bypass — and explain why in a code comment.

### "I'll add this as NEXT_PUBLIC_ so the client can read it"
Stop. `NEXT_PUBLIC_*` is inlined into every browser bundle. If it's secret, it's not public. The pattern for client-side access to server data is: client calls a Server Action, Server Action reads the secret, returns derived data.

### "I'll trust the client-supplied total amount, the form already shows it"
The client can be modified. Always recompute totals from line items server-side using `Decimal`. The schema in `invoiceSchema` doesn't even include `total` for this reason — it's calculated in the action.

### "Let me just use the admin client to make this easier"
Admin client bypasses ALL safety. If you find yourself reaching for it because RLS is in the way, you almost certainly have a permission model bug — fix the model, don't bypass it.

### "I'll log the user's email so I can debug"
PII in logs is a leak waiting to happen. Log user IDs (UUIDs), not identifiers. If you must log an email for a one-off investigation, redact it before commit.

---

## 6. Incident response

**If you suspect compromise:**

1. **Contain.** Rotate the relevant secret (service role key if data may be exposed). This invalidates all current admin access.
2. **Preserve evidence.** Don't `rm -rf` anything. Snapshot logs.
3. **Assess scope.** Query `audit_log` for unusual activity. Check Supabase API logs.
4. **Notify.** Per Kenya DPA 2019, you have **72 hours** to notify the ODPC of a personal data breach. Notify affected customers as required.
5. **Postmortem.** Write up what happened, what failed, what you changed. Share with the team.

**Pager rotation, runbooks, and escalation paths** are not in scope for this scaffold — set them up before you have real customers.

---

## 7. Compliance posture

| Regime | Status | Notes |
|---|---|---|
| Kenya DPA 2019 | Need DPO + privacy notice + breach plan before launch | Talk to a Kenyan privacy lawyer |
| GDPR | Out of scope unless EU customers | Same patterns apply if needed |
| PCI DSS | Avoided by using Stripe Checkout (we never see card data) | Don't add custom card forms |
| SOC 2 | Not pursued at scaffold stage | Revisit when you have enterprise customers |

---

## 8. What this scaffold does NOT include

You will need to add these before going live:

- WAF / DDoS protection (Cloudflare in front of Vercel is the easy answer)
- 2FA / MFA for users (Supabase supports TOTP — needs UI)
- Session management UI (revoke other sessions, list active devices)
- Account deletion / data export endpoints (DPA right to erasure / portability)
- Email transactional sending (Resend/Postmark — wire up in `lib/email/`)
- File upload virus scanning (ClamAV via Supabase Edge Function)
- Comprehensive E2E test suite (Playwright stub is in `package.json`)
- Penetration test by a third party (do this before public launch)
- Bug bounty program (consider once you have paying customers)
