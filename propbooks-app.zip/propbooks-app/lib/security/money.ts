// =====================================================================
// Money — exact decimal arithmetic
// =====================================================================
// Never use JavaScript Number for currency. 0.1 + 0.2 = 0.30000000000000004.
// All financial calculations go through Decimal.
// =====================================================================

import Decimal from 'decimal.js';

Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_EVEN });

export function d(v: string | number | Decimal): Decimal {
  return new Decimal(v);
}

export function lineAmount(qty: number, rate: number, discountPct = 0, taxPct = 0): {
  net: number;
  tax: number;
  total: number;
} {
  const dq = d(qty);
  const dr = d(rate);
  const gross = dq.mul(dr);
  const discount = gross.mul(d(discountPct).div(100));
  const net = gross.sub(discount);
  const tax = net.mul(d(taxPct).div(100));
  const total = net.add(tax);
  return {
    net: net.toDecimalPlaces(2).toNumber(),
    tax: tax.toDecimalPlaces(2).toNumber(),
    total: total.toDecimalPlaces(2).toNumber(),
  };
}

export function sum(values: Array<number | string>): number {
  return values
    .reduce((acc: Decimal, v) => acc.add(d(v)), new Decimal(0))
    .toDecimalPlaces(2)
    .toNumber();
}

export function formatKES(value: number | string): string {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 2,
  }).format(typeof value === 'string' ? parseFloat(value) : value);
}
