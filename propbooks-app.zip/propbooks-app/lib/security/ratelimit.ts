// =====================================================================
// Rate limiter — Upstash Redis
// =====================================================================
// Use on auth routes, signup, password reset, webhook ingest. Free tier
// covers small apps. Falls back to a no-op in development if not set.
// =====================================================================

import 'server-only';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const redisUrl = process.env.UPSTASH_REDIS_REST_URL;
const redisToken = process.env.UPSTASH_REDIS_REST_TOKEN;

const redis =
  redisUrl && redisToken
    ? new Redis({ url: redisUrl, token: redisToken })
    : null;

function build(prefix: string, limit: number, windowSec: number) {
  if (!redis) {
    // Dev fallback — never use in production
    return {
      limit: async (_key: string) => ({ success: true, remaining: limit, limit, reset: 0 }),
    };
  }
  return new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(limit, `${windowSec} s`),
    analytics: true,
    prefix,
  });
}

// 5 sign-in attempts / minute / IP
export const signInLimiter = build('rl:signin', 5, 60);
// 3 signups / hour / IP
export const signUpLimiter = build('rl:signup', 3, 3600);
// 100 mutations / minute / user
export const writeLimiter = build('rl:write', 100, 60);
// 1000 reads / minute / user
export const readLimiter = build('rl:read', 1000, 60);

export async function rateLimit(
  limiter: ReturnType<typeof build>,
  key: string,
) {
  const r = await limiter.limit(key);
  if (!r.success) {
    const err = new Error('Rate limit exceeded');
    (err as any).status = 429;
    (err as any).retryAfter = r.reset;
    throw err;
  }
  return r;
}
