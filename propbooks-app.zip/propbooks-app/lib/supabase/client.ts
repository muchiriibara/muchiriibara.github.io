// =====================================================================
// Browser-side Supabase client
// =====================================================================
// Uses the public ANON key. RLS policies in Postgres are the ONLY thing
// preventing users from reading each other's data — they are non-optional.
// Never put admin operations on the client.
// =====================================================================

import { createBrowserClient } from '@supabase/ssr';
import type { Database } from './database.types';

export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  );
}
