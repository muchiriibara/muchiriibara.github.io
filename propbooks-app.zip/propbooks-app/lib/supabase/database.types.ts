// =====================================================================
// Auto-generated Supabase types — placeholder
// =====================================================================
// After running migrations, regenerate this file with:
//   npx supabase gen types typescript --linked > lib/supabase/database.types.ts
// =====================================================================

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: Record<string, { Row: any; Insert: any; Update: any }>;
    Views: Record<string, { Row: any }>;
    Functions: {
      next_doc_number: { Args: { org: string; dtype: string }; Returns: string };
      user_orgs: { Args: Record<string, never>; Returns: string[] };
      user_role_in: { Args: { org: string }; Returns: 'owner' | 'admin' | 'accountant' | 'manager' | 'viewer' };
      user_has_role: {
        Args: { org: string; required: 'owner' | 'admin' | 'accountant' | 'manager' | 'viewer' };
        Returns: boolean;
      };
    };
    Enums: {
      org_role: 'owner' | 'admin' | 'accountant' | 'manager' | 'viewer';
      subscription_plan: 'starter' | 'growth' | 'professional' | 'enterprise';
      subscription_status: 'trialing' | 'active' | 'past_due' | 'canceled' | 'incomplete';
      document_status:
        | 'draft'
        | 'sent'
        | 'viewed'
        | 'accepted'
        | 'declined'
        | 'paid'
        | 'partial'
        | 'overdue'
        | 'void'
        | 'closed';
      payment_mode: 'mpesa' | 'bank_transfer' | 'cheque' | 'cash' | 'card' | 'other';
      lease_status: 'active' | 'expiring' | 'expired' | 'terminated' | 'pending';
    };
  };
};
