// =====================================================================
// Supabase ADMIN client — DANGER ZONE
// =====================================================================
// Uses the service_role key which BYPASSES Row-Level Security.
// Use ONLY for:
//   - Webhook handlers (Stripe, M-Pesa) where there's no user context
//   - Server-side cron jobs
//   - Admin operations after explicit authorization checks
//
// NEVER:
//   - Import this in a Client Component
//   - Pass results from this directly to the client without filtering
//   - Use this to "make queries simpler" — that defeats RLS
// =====================================================================

import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

let cached: ReturnType<typeof createClient<Database>> | null = null;

export function createAdminClient() {
  if (typeof window !== 'undefined') {
    throw new Error(
      'createAdminClient() called in browser. This is a critical security bug.',
    );
  }

  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set');
  }

  if (cached) return cached;

  cached = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    },
  );
  return cached;
}
