// =====================================================================
// Auth helpers — call these from Server Actions and Route Handlers
// =====================================================================
// requireUser()    — throws 401-style if no session
// requireOrg()     — throws 403 if user not in org
// requireRole()    — throws 403 if user lacks required role
// audit()          — append to audit_log via service role
// =====================================================================

import 'server-only';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import type { Database } from '@/lib/supabase/database.types';

export type OrgRole = Database['public']['Enums']['org_role'];

export class UnauthorizedError extends Error {
  status = 401;
}
export class ForbiddenError extends Error {
  status = 403;
}

export async function requireUser() {
  const supabase = await createClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();
  if (error || !user) {
    redirect('/login');
  }
  return user;
}

export async function getCurrentMembership(organizationId: string) {
  const supabase = await createClient();
  const user = await requireUser();
  const { data, error } = await supabase
    .from('memberships')
    .select('id, role, property_ids, accepted_at')
    .eq('user_id', user.id)
    .eq('organization_id', organizationId)
    .maybeSingle();
  if (error) throw error;
  if (!data || !data.accepted_at) {
    throw new ForbiddenError('Not a member of this organization');
  }
  return data;
}

const ROLE_RANK: Record<OrgRole, number> = {
  viewer: 1,
  manager: 2,
  accountant: 3,
  admin: 4,
  owner: 5,
};

export async function requireRole(organizationId: string, required: OrgRole) {
  const m = await getCurrentMembership(organizationId);
  if (ROLE_RANK[m.role] < ROLE_RANK[required]) {
    throw new ForbiddenError(`Requires role: ${required}`);
  }
  return m;
}

// Restrict a user to specific properties (if their membership has a list)
export async function assertCanAccessProperty(
  organizationId: string,
  propertyId: string,
) {
  const m = await getCurrentMembership(organizationId);
  if (m.property_ids && m.property_ids.length > 0 && !m.property_ids.includes(propertyId)) {
    throw new ForbiddenError('No access to this property');
  }
}

// =====================================================================
// Audit logging — called from Server Actions after a mutation
// =====================================================================
export async function audit(opts: {
  organizationId: string;
  actorId: string;
  action: string;
  resourceType: string;
  resourceId?: string | null;
  changes?: Record<string, unknown>;
}) {
  const admin = createAdminClient();
  const h = await headers();
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0]?.trim() || null;
  const ua = h.get('user-agent') || null;

  await admin.from('audit_log').insert({
    organization_id: opts.organizationId,
    actor_id: opts.actorId,
    action: opts.action,
    resource_type: opts.resourceType,
    resource_id: opts.resourceId ?? null,
    changes: opts.changes ?? null,
    ip_address: ip,
    user_agent: ua,
  });
}
