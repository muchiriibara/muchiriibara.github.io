// =====================================================================
// Validation schemas — Zod
// =====================================================================
// Every Server Action and Route Handler MUST parse input through one of
// these schemas. Never trust client-supplied JSON. This is your wall
// against XSS, SQL injection (via malformed inputs), and logic bugs.
// =====================================================================

import { z } from 'zod';

// ---------- Primitives ----------
export const uuid = z.string().uuid();
export const email = z.string().email().max(254).toLowerCase().trim();
export const phone = z.string().regex(/^\+?[0-9 \-()]{7,20}$/, 'Invalid phone number');
export const safeText = (min = 1, max = 200) =>
  z.string().trim().min(min).max(max);
export const money = z
  .number()
  .nonnegative()
  .max(999_999_999_999.99, 'Amount too large')
  .multipleOf(0.01, 'Max 2 decimal places');
export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date');

// ---------- Auth ----------
export const signInSchema = z.object({
  email,
  password: z.string().min(8).max(128),
});

export const signUpSchema = z.object({
  email,
  password: z
    .string()
    .min(12, 'Password must be at least 12 characters')
    .max(128)
    .regex(/[A-Z]/, 'Must contain an uppercase letter')
    .regex(/[a-z]/, 'Must contain a lowercase letter')
    .regex(/[0-9]/, 'Must contain a digit')
    .regex(/[^A-Za-z0-9]/, 'Must contain a symbol'),
  full_name: safeText(2, 100),
  organization_name: safeText(2, 100),
});

// ---------- Organization ----------
export const orgSchema = z.object({
  name: safeText(2, 100),
  country: z.string().length(2).default('KE'),
  currency: z.string().length(3).default('KES'),
  timezone: z.string().max(50).default('Africa/Nairobi'),
  fiscal_year_start_month: z.number().int().min(1).max(12).default(7),
});

// ---------- Membership / Invite ----------
export const inviteUserSchema = z.object({
  organization_id: uuid,
  email,
  role: z.enum(['admin', 'accountant', 'manager', 'viewer']),
  property_ids: z.array(uuid).nullable().optional(),
});

// ---------- Property ----------
export const propertySchema = z.object({
  name: safeText(2, 200),
  address: safeText(0, 500).optional(),
  city: safeText(0, 100).optional(),
  country: z.string().length(2).default('KE'),
  property_type: safeText(0, 50).optional(),
});

// ---------- Tenant ----------
export const tenantSchema = z.object({
  account_number: safeText(1, 50),
  full_name: safeText(2, 200),
  email: email.optional().or(z.literal('')),
  phone: phone.optional().or(z.literal('')),
  national_id: safeText(0, 30).optional(),
  kra_pin: safeText(0, 30).optional(),
  notes: safeText(0, 1000).optional(),
});

// ---------- Document line item ----------
export const lineItemSchema = z.object({
  item_name: safeText(1, 200),
  description: safeText(0, 1000).optional(),
  account: safeText(0, 100).optional(),
  quantity: z.number().positive().max(999_999),
  rate: money,
  discount_pct: z.number().min(0).max(100).default(0),
  tax_pct: z.number().min(0).max(100).default(0),
  period_label: safeText(0, 50).optional(),
  unit_id: uuid.optional(),
});

// ---------- Invoice ----------
export const invoiceSchema = z.object({
  property_id: uuid.optional(),
  tenant_id: uuid.optional(),
  customer_name: safeText(2, 200),
  invoice_date: isoDate,
  due_date: isoDate,
  payment_terms: safeText(0, 50).optional(),
  salesperson: safeText(0, 100).optional(),
  subject: safeText(0, 200).optional(),
  customer_notes: safeText(0, 2000).optional(),
  terms_conditions: safeText(0, 5000).optional(),
  shipping: money.default(0),
  adjustment: z.number().default(0),
  lines: z.array(lineItemSchema).min(1).max(200),
});

// ---------- Receipt ----------
export const receiptSchema = z.object({
  property_id: uuid.optional(),
  unit_id: uuid.optional(),
  tenant_id: uuid.optional(),
  payment_date: isoDate,
  received_from: safeText(2, 200),
  account_number: safeText(0, 50).optional(),
  unit_number: safeText(0, 20).optional(),
  property_name: safeText(0, 200).optional(),
  amount_received: money.refine((v) => v > 0, 'Must be > 0'),
  payment_mode: z.enum(['mpesa', 'bank_transfer', 'cheque', 'cash', 'card', 'other']),
  reference_number: safeText(0, 100).optional(),
  deposit_to_account: safeText(0, 100).optional(),
  bank_charges: money.default(0),
  tds_amount: money.default(0),
  customer_notes: safeText(0, 2000).optional(),
  received_by: safeText(0, 100).optional(),
  invoice_allocations: z
    .array(z.object({ invoice_id: uuid, amount: money }))
    .max(50)
    .optional(),
  lines: z.array(lineItemSchema).optional(),
});

// ---------- Bill / PO ----------
export const billSchema = z.object({
  vendor_name: safeText(2, 200),
  property_id: uuid.optional(),
  bill_date: isoDate,
  due_date: isoDate,
  reference: safeText(0, 100).optional(),
  payment_terms: safeText(0, 50).optional(),
  customer_notes: safeText(0, 2000).optional(),
  lines: z.array(lineItemSchema).min(1).max(200),
});

export const purchaseOrderSchema = z.object({
  vendor_name: safeText(2, 200),
  property_id: uuid.optional(),
  po_date: isoDate,
  expected_delivery: isoDate.optional(),
  reference: safeText(0, 100).optional(),
  ship_to: safeText(0, 500).optional(),
  customer_notes: safeText(0, 2000).optional(),
  terms: safeText(0, 5000).optional(),
  lines: z.array(lineItemSchema).min(1).max(200),
});

export const quoteSchema = z.object({
  property_id: uuid.optional(),
  tenant_id: uuid.optional(),
  customer_name: safeText(2, 200),
  quote_date: isoDate,
  expiry_date: isoDate.optional(),
  reference: safeText(0, 100).optional(),
  salesperson: safeText(0, 100).optional(),
  subject: safeText(0, 200).optional(),
  customer_notes: safeText(0, 2000).optional(),
  terms: safeText(0, 5000).optional(),
  lines: z.array(lineItemSchema).min(1).max(200),
});

export const salesOrderSchema = z.object({
  property_id: uuid.optional(),
  tenant_id: uuid.optional(),
  quote_id: uuid.optional(),
  customer_name: safeText(2, 200),
  order_date: isoDate,
  expected_shipment: isoDate.optional(),
  reference: safeText(0, 100).optional(),
  salesperson: safeText(0, 100).optional(),
  customer_notes: safeText(0, 2000).optional(),
  terms: safeText(0, 5000).optional(),
  lines: z.array(lineItemSchema).min(1).max(200),
});

export type SignInInput = z.infer<typeof signInSchema>;
export type SignUpInput = z.infer<typeof signUpSchema>;
export type InvoiceInput = z.infer<typeof invoiceSchema>;
export type ReceiptInput = z.infer<typeof receiptSchema>;
export type BillInput = z.infer<typeof billSchema>;
export type PurchaseOrderInput = z.infer<typeof purchaseOrderSchema>;
export type QuoteInput = z.infer<typeof quoteSchema>;
export type SalesOrderInput = z.infer<typeof salesOrderSchema>;
export type PropertyInput = z.infer<typeof propertySchema>;
export type TenantInput = z.infer<typeof tenantSchema>;
export type InviteUserInput = z.infer<typeof inviteUserSchema>;
