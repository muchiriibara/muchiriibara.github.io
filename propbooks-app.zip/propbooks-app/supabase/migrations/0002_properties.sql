-- =====================================================================
-- Migration 002: Properties, Units, Tenants, Leases
-- =====================================================================

-- ---- PROPERTIES -----------------------------------------------------
create table public.properties (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name            text not null check (length(name) between 2 and 200),
  address         text,
  city            text,
  country         text default 'KE',
  property_type   text,
  total_units     int default 0,
  metadata        jsonb default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz
);

create index idx_properties_org on public.properties(organization_id) where deleted_at is null;
create trigger properties_updated_at before update on public.properties
  for each row execute function public.set_updated_at();

-- ---- UNITS ----------------------------------------------------------
create table public.units (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  property_id     uuid not null references public.properties(id) on delete cascade,
  unit_number     text not null check (length(unit_number) between 1 and 20),
  floor           text,
  unit_type       text,
  bedrooms        int,
  bathrooms       int,
  square_meters   numeric(10,2),
  rent_amount     numeric(14,2) check (rent_amount >= 0),
  deposit_amount  numeric(14,2) check (deposit_amount >= 0),
  status          text default 'vacant' check (status in ('vacant','occupied','maintenance','reserved')),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(property_id, unit_number)
);

create index idx_units_org on public.units(organization_id);
create index idx_units_property on public.units(property_id);
create trigger units_updated_at before update on public.units
  for each row execute function public.set_updated_at();

-- ---- TENANTS --------------------------------------------------------
create table public.tenants (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  account_number  text not null,
  full_name       text not null check (length(full_name) between 2 and 200),
  email           citext,
  phone           text,
  national_id     text,
  kra_pin         text,
  emergency_contact jsonb,
  notes           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz,
  unique(organization_id, account_number)
);

create index idx_tenants_org on public.tenants(organization_id) where deleted_at is null;
create trigger tenants_updated_at before update on public.tenants
  for each row execute function public.set_updated_at();

-- ---- LEASES ---------------------------------------------------------
create table public.leases (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  tenant_id       uuid not null references public.tenants(id) on delete restrict,
  unit_id         uuid not null references public.units(id) on delete restrict,
  start_date      date not null,
  end_date        date not null,
  rent_amount     numeric(14,2) not null check (rent_amount >= 0),
  deposit_amount  numeric(14,2) check (deposit_amount >= 0),
  payment_day     int default 1 check (payment_day between 1 and 28),
  status          lease_status default 'active',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  check (end_date > start_date)
);

create index idx_leases_org on public.leases(organization_id);
create index idx_leases_tenant on public.leases(tenant_id);
create index idx_leases_unit on public.leases(unit_id);
create trigger leases_updated_at before update on public.leases
  for each row execute function public.set_updated_at();

-- =====================================================================
-- RLS — same pattern for all 4 tables: read-if-member, write-if-manager+
-- =====================================================================
alter table public.properties enable row level security;
alter table public.units      enable row level security;
alter table public.tenants    enable row level security;
alter table public.leases     enable row level security;

-- Macro: standard org-scoped policies
create policy "properties: org read" on public.properties for select
  using (organization_id = any(public.user_orgs()));
create policy "properties: manager write" on public.properties for insert
  with check (public.user_has_role(organization_id, 'manager'));
create policy "properties: manager update" on public.properties for update
  using (public.user_has_role(organization_id, 'manager'))
  with check (public.user_has_role(organization_id, 'manager'));
create policy "properties: admin delete" on public.properties for delete
  using (public.user_has_role(organization_id, 'admin'));

create policy "units: org read" on public.units for select
  using (organization_id = any(public.user_orgs()));
create policy "units: manager write" on public.units for insert
  with check (public.user_has_role(organization_id, 'manager'));
create policy "units: manager update" on public.units for update
  using (public.user_has_role(organization_id, 'manager'))
  with check (public.user_has_role(organization_id, 'manager'));
create policy "units: admin delete" on public.units for delete
  using (public.user_has_role(organization_id, 'admin'));

create policy "tenants: org read" on public.tenants for select
  using (organization_id = any(public.user_orgs()));
create policy "tenants: manager write" on public.tenants for insert
  with check (public.user_has_role(organization_id, 'manager'));
create policy "tenants: manager update" on public.tenants for update
  using (public.user_has_role(organization_id, 'manager'))
  with check (public.user_has_role(organization_id, 'manager'));
create policy "tenants: admin delete" on public.tenants for delete
  using (public.user_has_role(organization_id, 'admin'));

create policy "leases: org read" on public.leases for select
  using (organization_id = any(public.user_orgs()));
create policy "leases: manager write" on public.leases for insert
  with check (public.user_has_role(organization_id, 'manager'));
create policy "leases: manager update" on public.leases for update
  using (public.user_has_role(organization_id, 'manager'))
  with check (public.user_has_role(organization_id, 'manager'));
create policy "leases: admin delete" on public.leases for delete
  using (public.user_has_role(organization_id, 'admin'));
