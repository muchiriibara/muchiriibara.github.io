-- =====================================================================
-- Migration 001: Core schema
-- =====================================================================
-- Multi-tenant by `organization_id`. EVERY table that holds user data
-- has an organization_id column and a corresponding RLS policy.
--
-- Tenancy model:
--   auth.users (Supabase managed)
--     └─ profiles (1:1 with auth.users)
--     └─ memberships (M:N — user belongs to N orgs with a role per org)
--          └─ organizations
--               └─ properties, tenants, quotes, invoices, etc.
-- =====================================================================

-- Required extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- =====================================================================
-- ENUMS
-- =====================================================================
create type org_role as enum ('owner', 'admin', 'accountant', 'manager', 'viewer');
create type subscription_plan as enum ('starter', 'growth', 'professional', 'enterprise');
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'incomplete');
create type document_status as enum ('draft', 'sent', 'viewed', 'accepted', 'declined', 'paid', 'partial', 'overdue', 'void', 'closed');
create type payment_mode as enum ('mpesa', 'bank_transfer', 'cheque', 'cash', 'card', 'other');
create type lease_status as enum ('active', 'expiring', 'expired', 'terminated', 'pending');

-- =====================================================================
-- PROFILES (1:1 with auth.users)
-- =====================================================================
create table public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  email           citext unique not null,
  full_name       text,
  avatar_url      text,
  phone           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =====================================================================
-- ORGANIZATIONS (tenants of the SaaS itself, e.g. "Digihomes Agency")
-- =====================================================================
create table public.organizations (
  id                      uuid primary key default uuid_generate_v4(),
  name                    text not null check (length(name) between 2 and 100),
  slug                    text unique not null check (slug ~ '^[a-z0-9-]+$'),
  country                 text default 'KE',
  currency                text default 'KES' check (length(currency) = 3),
  timezone                text default 'Africa/Nairobi',
  fiscal_year_start_month int default 7 check (fiscal_year_start_month between 1 and 12),

  -- Subscription state
  plan                    subscription_plan default 'starter',
  subscription_status     subscription_status default 'trialing',
  trial_ends_at           timestamptz default (now() + interval '14 days'),
  stripe_customer_id      text unique,
  stripe_subscription_id  text unique,

  -- Limits (enforced at app + DB layer)
  max_users               int default 2,
  max_properties          int default 1,

  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

create index idx_orgs_stripe_customer on public.organizations(stripe_customer_id) where stripe_customer_id is not null;

-- =====================================================================
-- MEMBERSHIPS (user ↔ org, with role)
-- =====================================================================
create table public.memberships (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references public.profiles(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  role            org_role not null default 'viewer',
  -- Optional: restrict user to specific properties (null = all)
  property_ids    uuid[] default null,
  invited_by      uuid references public.profiles(id),
  invited_at      timestamptz default now(),
  accepted_at     timestamptz,
  created_at      timestamptz not null default now(),
  unique(user_id, organization_id)
);

create index idx_memberships_user on public.memberships(user_id);
create index idx_memberships_org on public.memberships(organization_id);

-- =====================================================================
-- HELPER FUNCTIONS for RLS
-- =====================================================================
-- These functions are SECURITY DEFINER so they can read membership rows
-- to determine the caller's permissions without RLS recursion.

-- Returns array of org IDs the current user belongs to
create or replace function public.user_orgs()
returns uuid[]
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(array_agg(organization_id), '{}'::uuid[])
  from public.memberships
  where user_id = auth.uid() and accepted_at is not null;
$$;

-- Returns the user's role in a specific org (null if not a member)
create or replace function public.user_role_in(org uuid)
returns org_role
language sql
security definer
stable
set search_path = public
as $$
  select role from public.memberships
  where user_id = auth.uid() and organization_id = org and accepted_at is not null
  limit 1;
$$;

-- True if user has at least the required role in the org
create or replace function public.user_has_role(org uuid, required org_role)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select case public.user_role_in(org)
    when 'owner'      then true
    when 'admin'      then required <> 'owner'
    when 'accountant' then required in ('accountant', 'manager', 'viewer')
    when 'manager'    then required in ('manager', 'viewer')
    when 'viewer'     then required = 'viewer'
    else false
  end;
$$;

-- updated_at trigger helper
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger organizations_updated_at before update on public.organizations
  for each row execute function public.set_updated_at();

-- =====================================================================
-- ENABLE RLS on all public tables
-- =====================================================================
alter table public.profiles      enable row level security;
alter table public.organizations enable row level security;
alter table public.memberships   enable row level security;

-- =====================================================================
-- RLS POLICIES — profiles
-- =====================================================================
-- A user can see their own profile, plus profiles of co-members in any org
create policy "profiles: self read"
  on public.profiles for select
  using (id = auth.uid());

create policy "profiles: co-member read"
  on public.profiles for select
  using (
    exists (
      select 1 from public.memberships m1
      join public.memberships m2 on m1.organization_id = m2.organization_id
      where m1.user_id = auth.uid() and m2.user_id = profiles.id
    )
  );

create policy "profiles: self update"
  on public.profiles for update
  using (id = auth.uid())
  with check (id = auth.uid());

-- =====================================================================
-- RLS POLICIES — organizations
-- =====================================================================
create policy "orgs: members read"
  on public.organizations for select
  using (id = any(public.user_orgs()));

create policy "orgs: owner update"
  on public.organizations for update
  using (public.user_has_role(id, 'owner'))
  with check (public.user_has_role(id, 'owner'));

-- Insert handled by Server Action (creates org + owner membership atomically)
-- Delete is intentionally restricted to admins via service role only.

-- =====================================================================
-- RLS POLICIES — memberships
-- =====================================================================
create policy "memberships: read same org"
  on public.memberships for select
  using (organization_id = any(public.user_orgs()));

create policy "memberships: admin manage"
  on public.memberships for all
  using (public.user_has_role(organization_id, 'admin'))
  with check (public.user_has_role(organization_id, 'admin'));
