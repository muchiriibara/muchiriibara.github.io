-- =====================================================================
-- Migration 003: Financial Documents
-- =====================================================================
-- Quotes, Sales Orders, Invoices, Payment Receipts, Bills, Purchase Orders.
--
-- Numeric columns: numeric(14,2) — supports up to 999,999,999,999.99 (KES).
-- All money in minor units would be safer, but numeric(14,2) is acceptable
-- with disciplined application-side rounding using decimal.js.
--
-- Document numbering: per-org sequences via the document_sequences table
-- so two orgs don't collide and INV-001 stays predictable per tenant.
-- =====================================================================

-- ---- DOCUMENT SEQUENCES (per-org auto-numbering) -------------------
create table public.document_sequences (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  doc_type        text not null check (doc_type in
    ('quote','sales_order','invoice','receipt','bill','purchase_order')),
  prefix          text not null,
  next_number     bigint not null default 1,
  primary key (organization_id, doc_type)
);

alter table public.document_sequences enable row level security;
create policy "doc_seq: org read" on public.document_sequences for select
  using (organization_id = any(public.user_orgs()));

-- Atomic next-number function (called server-side only, security definer)
create or replace function public.next_doc_number(org uuid, dtype text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  seq_prefix text;
  seq_num    bigint;
begin
  -- Verify caller has access (defense in depth — RLS won't fire in definer)
  if not (org = any(public.user_orgs())) then
    raise exception 'Access denied to organization' using errcode = '42501';
  end if;

  insert into public.document_sequences (organization_id, doc_type, prefix, next_number)
  values (org, dtype, upper(left(dtype,3)), 1)
  on conflict (organization_id, doc_type) do nothing;

  update public.document_sequences
     set next_number = next_number + 1
   where organization_id = org and doc_type = dtype
   returning prefix, next_number - 1 into seq_prefix, seq_num;

  return seq_prefix || '-' || lpad(seq_num::text, 6, '0');
end;
$$;

-- ---- QUOTES ---------------------------------------------------------
create table public.quotes (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  property_id     uuid references public.properties(id),
  tenant_id       uuid references public.tenants(id),
  customer_name   text not null,
  quote_number    text not null,
  reference       text,
  quote_date      date not null default current_date,
  expiry_date     date,
  salesperson     text,
  subject         text,
  customer_notes  text,
  terms           text,
  subtotal        numeric(14,2) not null default 0 check (subtotal >= 0),
  tax_total       numeric(14,2) not null default 0 check (tax_total >= 0),
  discount_total  numeric(14,2) not null default 0 check (discount_total >= 0),
  shipping        numeric(14,2) not null default 0,
  adjustment      numeric(14,2) not null default 0,
  total           numeric(14,2) not null default 0 check (total >= 0),
  currency        text not null default 'KES',
  status          document_status not null default 'draft',
  tags            text[] default '{}',
  metadata        jsonb default '{}'::jsonb,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(organization_id, quote_number)
);

create index idx_quotes_org_status on public.quotes(organization_id, status);
create index idx_quotes_property on public.quotes(property_id);
create trigger quotes_updated_at before update on public.quotes
  for each row execute function public.set_updated_at();

-- ---- SALES ORDERS ---------------------------------------------------
create table public.sales_orders (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  property_id     uuid references public.properties(id),
  tenant_id       uuid references public.tenants(id),
  quote_id        uuid references public.quotes(id),
  customer_name   text not null,
  order_number    text not null,
  reference       text,
  order_date      date not null default current_date,
  expected_shipment date,
  salesperson     text,
  customer_notes  text,
  terms           text,
  subtotal        numeric(14,2) not null default 0,
  tax_total       numeric(14,2) not null default 0,
  discount_total  numeric(14,2) not null default 0,
  shipping        numeric(14,2) not null default 0,
  adjustment      numeric(14,2) not null default 0,
  total           numeric(14,2) not null default 0,
  currency        text not null default 'KES',
  status          document_status not null default 'draft',
  metadata        jsonb default '{}'::jsonb,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(organization_id, order_number)
);

create index idx_so_org_status on public.sales_orders(organization_id, status);
create trigger so_updated_at before update on public.sales_orders
  for each row execute function public.set_updated_at();

-- ---- INVOICES -------------------------------------------------------
create table public.invoices (
  id                  uuid primary key default uuid_generate_v4(),
  organization_id     uuid not null references public.organizations(id) on delete cascade,
  property_id         uuid references public.properties(id),
  tenant_id           uuid references public.tenants(id),
  sales_order_id      uuid references public.sales_orders(id),
  customer_name       text not null,
  invoice_number      text not null,
  order_number        text,
  invoice_date        date not null default current_date,
  due_date            date not null,
  payment_terms       text,
  salesperson         text,
  subject             text,
  project             text,
  customer_notes      text,
  terms_conditions    text,
  payment_options     jsonb default '{}'::jsonb,
  subtotal            numeric(14,2) not null default 0,
  tax_total           numeric(14,2) not null default 0,
  discount_total      numeric(14,2) not null default 0,
  shipping            numeric(14,2) not null default 0,
  adjustment          numeric(14,2) not null default 0,
  total               numeric(14,2) not null default 0 check (total >= 0),
  amount_paid         numeric(14,2) not null default 0 check (amount_paid >= 0),
  balance_due         numeric(14,2) generated always as (total - amount_paid) stored,
  currency            text not null default 'KES',
  status              document_status not null default 'draft',
  tags                text[] default '{}',
  reporting_tags      jsonb default '{}'::jsonb,
  metadata            jsonb default '{}'::jsonb,
  created_by          uuid references public.profiles(id),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique(organization_id, invoice_number),
  check (due_date >= invoice_date),
  check (amount_paid <= total)
);

create index idx_invoices_org_status on public.invoices(organization_id, status);
create index idx_invoices_due on public.invoices(due_date) where status in ('sent','partial','overdue');
create index idx_invoices_tenant on public.invoices(tenant_id);
create trigger invoices_updated_at before update on public.invoices
  for each row execute function public.set_updated_at();

-- ---- PAYMENT RECEIPTS ----------------------------------------------
create table public.payment_receipts (
  id                  uuid primary key default uuid_generate_v4(),
  organization_id     uuid not null references public.organizations(id) on delete cascade,
  property_id         uuid references public.properties(id),
  unit_id             uuid references public.units(id),
  tenant_id           uuid references public.tenants(id),
  receipt_number      text not null,
  payment_date        date not null default current_date,
  -- Tenant snapshot (Digihomes-style fields)
  received_from       text not null,
  account_number      text,
  unit_number         text,
  property_name       text,
  -- Payment fields (Zoho-style)
  amount_received     numeric(14,2) not null check (amount_received > 0),
  payment_mode        payment_mode not null,
  reference_number    text,
  deposit_to_account  text,
  bank_charges        numeric(14,2) default 0 check (bank_charges >= 0),
  tds_amount          numeric(14,2) default 0 check (tds_amount >= 0),
  adjustment          numeric(14,2) default 0,
  excess_amount       numeric(14,2) default 0 check (excess_amount >= 0),
  customer_notes      text,
  terms               text,
  received_by         text,
  currency            text not null default 'KES',
  status              text default 'completed' check (status in ('completed','reversed','pending')),
  metadata            jsonb default '{}'::jsonb,
  created_by          uuid references public.profiles(id),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique(organization_id, receipt_number)
);

create index idx_receipts_org_date on public.payment_receipts(organization_id, payment_date desc);
create index idx_receipts_tenant on public.payment_receipts(tenant_id);
create trigger receipts_updated_at before update on public.payment_receipts
  for each row execute function public.set_updated_at();

-- Receipt-to-invoice allocation (pay one or many invoices)
create table public.receipt_allocations (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  receipt_id      uuid not null references public.payment_receipts(id) on delete cascade,
  invoice_id      uuid not null references public.invoices(id) on delete restrict,
  amount          numeric(14,2) not null check (amount > 0),
  created_at      timestamptz not null default now()
);
create index idx_alloc_receipt on public.receipt_allocations(receipt_id);
create index idx_alloc_invoice on public.receipt_allocations(invoice_id);

-- ---- BILLS ----------------------------------------------------------
create table public.bills (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  property_id     uuid references public.properties(id),
  vendor_name     text not null,
  bill_number     text not null,
  reference       text,
  bill_date       date not null default current_date,
  due_date        date not null,
  payment_terms   text,
  customer_notes  text,
  subtotal        numeric(14,2) not null default 0,
  tax_total       numeric(14,2) not null default 0,
  total           numeric(14,2) not null default 0,
  amount_paid     numeric(14,2) not null default 0,
  balance_due     numeric(14,2) generated always as (total - amount_paid) stored,
  currency        text not null default 'KES',
  status          document_status not null default 'draft',
  metadata        jsonb default '{}'::jsonb,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(organization_id, bill_number)
);

create index idx_bills_org on public.bills(organization_id, status);
create trigger bills_updated_at before update on public.bills
  for each row execute function public.set_updated_at();

-- ---- PURCHASE ORDERS ------------------------------------------------
create table public.purchase_orders (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  property_id     uuid references public.properties(id),
  vendor_name     text not null,
  po_number       text not null,
  reference       text,
  po_date         date not null default current_date,
  expected_delivery date,
  ship_to         text,
  customer_notes  text,
  terms           text,
  subtotal        numeric(14,2) not null default 0,
  tax_total       numeric(14,2) not null default 0,
  total           numeric(14,2) not null default 0,
  currency        text not null default 'KES',
  status          document_status not null default 'draft',
  metadata        jsonb default '{}'::jsonb,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(organization_id, po_number)
);

create index idx_po_org on public.purchase_orders(organization_id, status);
create trigger po_updated_at before update on public.purchase_orders
  for each row execute function public.set_updated_at();

-- ---- LINE ITEMS (shared by all document types) ---------------------
create table public.document_lines (
  id              uuid primary key default uuid_generate_v4(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  doc_type        text not null check (doc_type in
    ('quote','sales_order','invoice','bill','purchase_order')),
  doc_id          uuid not null,
  sort_order      int not null default 0,
  item_name       text not null,
  description     text,
  account         text,
  quantity        numeric(14,4) not null default 1 check (quantity > 0),
  rate            numeric(14,4) not null default 0 check (rate >= 0),
  discount_pct    numeric(5,2) default 0 check (discount_pct between 0 and 100),
  tax_pct         numeric(5,2) default 0 check (tax_pct between 0 and 100),
  amount          numeric(14,2) not null default 0,
  -- Real estate specific
  period_label    text,
  unit_id         uuid references public.units(id),
  created_at      timestamptz not null default now()
);

create index idx_doclines_doc on public.document_lines(doc_type, doc_id);
create index idx_doclines_org on public.document_lines(organization_id);

-- =====================================================================
-- AUDIT LOG (immutable trail of sensitive actions)
-- =====================================================================
create table public.audit_log (
  id              bigserial primary key,
  organization_id uuid references public.organizations(id) on delete set null,
  actor_id        uuid references public.profiles(id) on delete set null,
  action          text not null,
  resource_type   text not null,
  resource_id     uuid,
  changes         jsonb,
  ip_address      inet,
  user_agent      text,
  created_at      timestamptz not null default now()
);

create index idx_audit_org_time on public.audit_log(organization_id, created_at desc);
create index idx_audit_resource on public.audit_log(resource_type, resource_id);

-- Audit log is read-only via app, append-only at DB level
revoke insert, update, delete on public.audit_log from authenticated;
revoke insert, update, delete on public.audit_log from anon;

-- =====================================================================
-- ENABLE RLS on all financial tables
-- =====================================================================
alter table public.quotes              enable row level security;
alter table public.sales_orders        enable row level security;
alter table public.invoices            enable row level security;
alter table public.payment_receipts    enable row level security;
alter table public.receipt_allocations enable row level security;
alter table public.bills               enable row level security;
alter table public.purchase_orders     enable row level security;
alter table public.document_lines      enable row level security;
alter table public.audit_log           enable row level security;

-- =====================================================================
-- Standard org-scoped policies for financial docs
-- Read: any member. Write: accountant+. Delete: admin+.
-- =====================================================================
do $$
declare
  t text;
  tables text[] := array['quotes','sales_orders','invoices','payment_receipts',
                         'receipt_allocations','bills','purchase_orders','document_lines'];
begin
  foreach t in array tables loop
    execute format($f$
      create policy "%1$s: org read" on public.%1$I for select
        using (organization_id = any(public.user_orgs()));
      create policy "%1$s: accountant write" on public.%1$I for insert
        with check (public.user_has_role(organization_id, 'accountant'));
      create policy "%1$s: accountant update" on public.%1$I for update
        using (public.user_has_role(organization_id, 'accountant'))
        with check (public.user_has_role(organization_id, 'accountant'));
      create policy "%1$s: admin delete" on public.%1$I for delete
        using (public.user_has_role(organization_id, 'admin'));
    $f$, t);
  end loop;
end $$;

-- Audit log: read-only for members, no writes from app
create policy "audit: org read" on public.audit_log for select
  using (organization_id = any(public.user_orgs()) and public.user_has_role(organization_id, 'admin'));
