# PropBooks

Multi-property accounting and tenant management for real estate operators.

Built on Next.js 15 (App Router) + Supabase (Postgres, Auth, RLS) + Stripe + Vercel.

## Status

This is a **production scaffold**, not a finished product. It contains:

- ✅ Real auth (email/password, ready for Google/Microsoft/Apple SSO)
- ✅ Multi-tenant Postgres schema with RLS on every table
- ✅ Hardened security headers, CSP with nonces, rate limiting
- ✅ Server Actions with Zod validation, role-based authorization, audit logging
- ✅ Stripe webhook with signature verification (subscription events)
- ✅ M-Pesa Daraja STK callback skeleton
- ✅ Money math via `decimal.js` (no float bugs)
- ✅ Full deployment guide for Vercel + Supabase

It does NOT contain:
- Finished UI for every module (only Login, Signup, Dashboard, Invoices have real implementations — others are stubs)
- Email transactional sending
- File uploads / document storage
- 2FA / session management UI
- WhatsApp bot
- M-Pesa STK initiation (only the callback receiver)
- Tests beyond stubs

Treat this as a foundation you build on, not a turnkey app.

## Quick start

```bash
npm install
cp .env.example .env.local
# Fill in Supabase + Stripe + Upstash keys
supabase link --project-ref <ref>
supabase db push
npm run db:types
npm run dev
```

## Documentation

- [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) — step-by-step Vercel + Supabase deployment
- [`docs/SECURITY.md`](docs/SECURITY.md) — threat model, defense layers, code review checklist

## Project layout

```
app/
  (auth)/          login, signup, OAuth callback
  (app)/           authenticated pages — dashboard, invoices, etc.
  api/
    health/        liveness probe
    webhooks/      Stripe + M-Pesa webhooks (no auth, signature-verified)
lib/
  supabase/        client, server, admin (service-role)
  auth/            requireUser, requireRole, audit
  validation/      Zod schemas for every input
  security/        rate limiter, money math
supabase/
  migrations/      SQL — schema + RLS policies
middleware.ts      auth gate, CSP nonce, session refresh
next.config.mjs    security headers
```

## License

Private. © 2026 PropBooks · Built and maintained by Lucent Aura.
