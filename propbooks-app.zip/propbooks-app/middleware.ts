// =====================================================================
// Edge Middleware
// =====================================================================
// Runs before every request. Three jobs:
//  1) Refresh Supabase auth session (cookies)
//  2) Enforce auth on protected routes
//  3) Inject per-request CSP nonce (defense against XSS)
//  4) Apply rate limiting on sensitive routes
// =====================================================================

import { type NextRequest, NextResponse } from 'next/server';
import { createServerClient, type CookieOptions } from '@supabase/ssr';

// Routes that require authentication
const PROTECTED_PREFIXES = [
  '/dashboard',
  '/properties',
  '/tenants',
  '/quotes',
  '/invoices',
  '/receipts',
  '/sales-orders',
  '/bills',
  '/purchase-orders',
  '/users',
  '/subscription',
  '/settings',
];

// Routes accessible only when NOT logged in
const PUBLIC_AUTH_ROUTES = ['/login', '/signup'];

export async function middleware(request: NextRequest) {
  // ---- 1. Generate per-request CSP nonce ----
  const nonce = Buffer.from(crypto.randomUUID()).toString('base64');
  const cspHeader = buildCSP(nonce);

  // ---- 2. Set up Supabase session refresh ----
  let response = NextResponse.next({
    request: { headers: new Headers(request.headers) },
  });
  response.headers.set('x-nonce', nonce);
  response.headers.set('Content-Security-Policy', cspHeader);

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          );
          response = NextResponse.next({ request });
          response.headers.set('x-nonce', nonce);
          response.headers.set('Content-Security-Policy', cspHeader);
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, {
              ...options,
              // Hardened cookie defaults
              httpOnly: true,
              secure: process.env.NODE_ENV === 'production',
              sameSite: 'lax',
              path: '/',
            } as CookieOptions),
          );
        },
      },
    },
  );

  // IMPORTANT: do not put any auth logic between createServerClient and getUser.
  // getUser revalidates the session token with Supabase Auth.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isProtected = PROTECTED_PREFIXES.some((p) => path.startsWith(p));
  const isAuthRoute = PUBLIC_AUTH_ROUTES.some((p) => path.startsWith(p));

  // ---- 3. Enforce auth ----
  if (isProtected && !user) {
    const redirect = request.nextUrl.clone();
    redirect.pathname = '/login';
    redirect.searchParams.set('next', path);
    return NextResponse.redirect(redirect);
  }

  if (isAuthRoute && user) {
    const redirect = request.nextUrl.clone();
    redirect.pathname = '/dashboard';
    return NextResponse.redirect(redirect);
  }

  return response;
}

function buildCSP(nonce: string): string {
  const directives = [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic' https://js.stripe.com`,
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "img-src 'self' blob: data: https://*.supabase.co",
    "font-src 'self' https://fonts.gstatic.com",
    "connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.stripe.com",
    "frame-src 'self' https://js.stripe.com https://hooks.stripe.com",
    "frame-ancestors 'none'",
    "form-action 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    'upgrade-insecure-requests',
  ];
  return directives.join('; ');
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico, robots.txt, sitemap.xml
     * - api/webhooks/* (have their own signature verification)
     */
    '/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|api/webhooks).*)',
  ],
};
