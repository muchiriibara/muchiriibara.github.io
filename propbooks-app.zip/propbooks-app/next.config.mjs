/** @type {import('next').NextConfig} */

// =====================================================================
// Content Security Policy
// =====================================================================
// Strict CSP. Adjust 'connect-src' and 'frame-src' as you add 3rd parties.
// 'unsafe-inline' on style-src is required by Next.js 15 + Tailwind in
// production for some inline styles. Script-src uses a per-request nonce
// (set in middleware.ts) — never use 'unsafe-inline' for scripts.
// =====================================================================

const ContentSecurityPolicy = `
  default-src 'self';
  script-src 'self' 'nonce-{NONCE}' 'strict-dynamic' https://js.stripe.com;
  style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
  img-src 'self' blob: data: https://*.supabase.co;
  font-src 'self' https://fonts.gstatic.com;
  connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.stripe.com https://api.safaricom.co.ke;
  frame-src 'self' https://js.stripe.com https://hooks.stripe.com;
  frame-ancestors 'none';
  form-action 'self';
  base-uri 'self';
  object-src 'none';
  upgrade-insecure-requests;
  block-all-mixed-content;
`.replace(/\s{2,}/g, ' ').trim();

const securityHeaders = [
  // Force HTTPS for 2 years, include subdomains, eligible for preload list
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  // Block embedding in iframes (clickjacking)
  { key: 'X-Frame-Options', value: 'DENY' },
  // Prevent MIME sniffing
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  // Limit referrer leakage
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  // Disable powerful browser APIs you don't use
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=(), interest-cohort=(), payment=(self "https://js.stripe.com")',
  },
  // Cross-origin isolation
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'Cross-Origin-Resource-Policy', value: 'same-origin' },
  // Legacy XSS filter (modern browsers ignore but harmless)
  { key: 'X-XSS-Protection', value: '0' },
  // Don't reveal we're Next.js
  { key: 'X-Powered-By', value: '' },
];

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,

  // Block builds if there are TS or lint errors — production safety
  typescript: { ignoreBuildErrors: false },
  eslint: { ignoreDuringBuilds: false },

  // Production-only: opt out of source maps to reduce attack surface
  productionBrowserSourceMaps: false,

  experimental: {
    // Restrict server actions to same-origin
    serverActions: {
      allowedOrigins: process.env.NEXT_PUBLIC_APP_URL
        ? [new URL(process.env.NEXT_PUBLIC_APP_URL).host]
        : [],
    },
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          ...securityHeaders,
          {
            key: 'Content-Security-Policy',
            // Note: nonce is replaced per-request by middleware.ts
            value: ContentSecurityPolicy,
          },
        ],
      },
      // Long cache for static assets
      {
        source: '/_next/static/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
    ];
  },

  async redirects() {
    return [
      // Force www → apex (or apex → www, choose one)
      // { source: '/(.*)', has: [{ type: 'host', value: 'www.propbooks.io' }],
      //   destination: 'https://propbooks.io/:path*', permanent: true },
    ];
  },
};

export default nextConfig;
