import type { Metadata } from 'next';
import { headers } from 'next/headers';
import './globals.css';

export const metadata: Metadata = {
  title: 'PropBooks — Real Estate Accounting',
  description: 'Multi-property accounting and tenant management',
  robots: { index: false, follow: false }, // Keep app private from search
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const nonce = (await headers()).get('x-nonce') ?? undefined;

  return (
    <html lang="en">
      <head>
        {/* Nonce is propagated to next/script via this meta tag pattern */}
        {nonce && <meta name="csp-nonce" content={nonce} />}
      </head>
      <body className="bg-zinc-950 text-zinc-100 antialiased">
        {children}
      </body>
    </html>
  );
}
