import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { signOutAction } from '../(auth)/actions';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('full_name, email')
    .eq('id', user.id)
    .single();

  // Pull memberships — first one is the active org for now.
  // Multi-org switcher is a later feature.
  const { data: memberships } = await supabase
    .from('memberships')
    .select('organization_id, role, organizations(name)')
    .eq('user_id', user.id)
    .not('accepted_at', 'is', null)
    .limit(1);

  const activeOrg = memberships?.[0];

  return (
    <div className="flex h-screen overflow-hidden">
      <aside className="w-64 flex-shrink-0 border-r border-zinc-800 bg-zinc-900 flex flex-col">
        <div className="border-b border-zinc-800 p-4">
          <div className="text-lg font-bold">
            Prop<span className="text-emerald-400">Books</span>
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-zinc-500">
            {activeOrg?.organizations?.name ?? 'No organization'}
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-2 space-y-1 text-sm">
          <NavGroup label="Overview">
            <NavLink href="/dashboard">Dashboard</NavLink>
            <NavLink href="/properties">Properties</NavLink>
            <NavLink href="/tenants">Tenants</NavLink>
          </NavGroup>
          <NavGroup label="Sales">
            <NavLink href="/quotes">Quotes</NavLink>
            <NavLink href="/sales-orders">Sales Orders</NavLink>
            <NavLink href="/invoices">Invoices</NavLink>
            <NavLink href="/receipts">Payment Receipts</NavLink>
          </NavGroup>
          <NavGroup label="Purchasing">
            <NavLink href="/purchase-orders">Purchase Orders</NavLink>
            <NavLink href="/bills">Bills</NavLink>
          </NavGroup>
          <NavGroup label="Account">
            <NavLink href="/users">Users &amp; Roles</NavLink>
            <NavLink href="/subscription">Subscription</NavLink>
            <NavLink href="/settings">Settings</NavLink>
          </NavGroup>
        </nav>

        <div className="border-t border-zinc-800 p-4">
          <div className="text-xs font-medium">{profile?.full_name ?? 'User'}</div>
          <div className="text-[10px] text-zinc-500">{profile?.email}</div>
          <form action={signOutAction} className="mt-2">
            <button className="text-xs text-zinc-400 hover:text-emerald-400">Sign out</button>
          </form>
          <div className="mt-3 text-center text-[10px] text-zinc-600">
            © 2026 PropBooks
            <br />
            Built by <span className="text-zinc-500">Lucent Aura</span>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}

function NavGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <div className="px-3 py-1 text-[9px] font-bold uppercase tracking-widest text-zinc-500">
        {label}
      </div>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="block rounded-md px-3 py-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white"
    >
      {children}
    </Link>
  );
}
