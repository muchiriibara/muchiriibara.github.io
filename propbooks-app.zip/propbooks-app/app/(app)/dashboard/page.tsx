import { createClient } from '@/lib/supabase/server';
import { formatKES } from '@/lib/security/money';

export default async function DashboardPage() {
  const supabase = await createClient();

  // Parallel queries — RLS ensures we only see our org's data
  const [
    { count: propertyCount },
    { count: tenantCount },
    { data: openInvoices },
    { data: recentReceipts },
  ] = await Promise.all([
    supabase.from('properties').select('id', { count: 'exact', head: true }).is('deleted_at', null),
    supabase.from('tenants').select('id', { count: 'exact', head: true }).is('deleted_at', null),
    supabase
      .from('invoices')
      .select('id, balance_due')
      .in('status', ['sent', 'partial', 'overdue']),
    supabase
      .from('payment_receipts')
      .select('receipt_number, payment_date, received_from, amount_received')
      .order('payment_date', { ascending: false })
      .limit(5),
  ]);

  const outstanding = (openInvoices ?? []).reduce(
    (acc, i) => acc + Number(i.balance_due ?? 0),
    0,
  );

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      <div className="grid grid-cols-4 gap-4 mb-8">
        <Stat label="Properties" value={propertyCount?.toString() ?? '0'} />
        <Stat label="Active Tenants" value={tenantCount?.toString() ?? '0'} />
        <Stat label="Outstanding" value={formatKES(outstanding)} accent="red" />
        <Stat label="Open Invoices" value={(openInvoices?.length ?? 0).toString()} />
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
        <h2 className="text-sm font-semibold mb-4">Recent Receipts</h2>
        {recentReceipts?.length ? (
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-zinc-500">
              <tr>
                <th className="pb-2">Receipt #</th>
                <th className="pb-2">Date</th>
                <th className="pb-2">From</th>
                <th className="pb-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {recentReceipts.map((r) => (
                <tr key={r.receipt_number} className="border-t border-zinc-800">
                  <td className="py-2 font-mono text-xs text-emerald-400">{r.receipt_number}</td>
                  <td className="py-2">{r.payment_date}</td>
                  <td className="py-2">{r.received_from}</td>
                  <td className="py-2 text-right">{formatKES(r.amount_received)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-sm text-zinc-500">No receipts yet.</p>
        )}
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: 'red' | 'green';
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
      <div className="text-xs uppercase tracking-wide text-zinc-500">{label}</div>
      <div
        className={`mt-2 text-2xl font-bold ${
          accent === 'red' ? 'text-red-400' : accent === 'green' ? 'text-emerald-400' : ''
        }`}
      >
        {value}
      </div>
    </div>
  );
}
