import { createClient } from '@/lib/supabase/server';

export default async function Page() {
  const supabase = await createClient();
  // RLS automatically scopes to current user's org
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Sales Orders</h1>
      <p className="text-zinc-400 text-sm">
        Implement this page following the pattern in{' '}
        <code className="text-emerald-400">app/(app)/invoices/</code>:
      </p>
      <ul className="mt-4 list-disc list-inside text-sm text-zinc-400 space-y-1">
        <li>Server Component fetches data via createClient (RLS-scoped)</li>
        <li>Server Action validates with Zod, requires role, audits, transacts</li>
        <li>Forms use action prop pointing at the Server Action</li>
      </ul>
    </div>
  );
}
