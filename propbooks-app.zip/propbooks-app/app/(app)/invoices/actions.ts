'use server';

// =====================================================================
// Invoice Server Actions — copy this pattern for every other resource
// =====================================================================
// Pattern:
//   1. requireUser()                   — auth gate
//   2. parse with Zod                  — input validation
//   3. requireRole() / assertCanAccess — authorization
//   4. rate limit                      — abuse protection
//   5. compute totals server-side      — never trust client math
//   6. insert + lines in transaction   — data integrity
//   7. audit()                         — immutable trail
//   8. revalidatePath()                — refresh server cache
// =====================================================================

import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requireUser, requireRole, audit } from '@/lib/auth/guards';
import { invoiceSchema } from '@/lib/validation/schemas';
import { rateLimit, writeLimiter } from '@/lib/security/ratelimit';
import { lineAmount, sum, d } from '@/lib/security/money';

export async function createInvoice(input: {
  organization_id: string;
  invoice: unknown; // validated below
}) {
  // 1. Auth
  const user = await requireUser();

  // 2. Validate
  const parsed = invoiceSchema.safeParse(input.invoice);
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? 'Invalid input' };
  }
  const inv = parsed.data;

  // 3. Authorization
  await requireRole(input.organization_id, 'accountant');

  // 4. Rate limit
  await rateLimit(writeLimiter, `invoice-create:${user.id}`);

  // 5. Compute totals server-side (NEVER trust client)
  const lines = inv.lines.map((l) => {
    const calc = lineAmount(l.quantity, l.rate, l.discount_pct, l.tax_pct);
    return { ...l, ...calc };
  });
  const subtotal = sum(lines.map((l) => l.net));
  const taxTotal = sum(lines.map((l) => l.tax));
  const total = d(subtotal)
    .add(taxTotal)
    .add(inv.shipping ?? 0)
    .add(inv.adjustment ?? 0)
    .toDecimalPlaces(2)
    .toNumber();

  // 6. Get next invoice number atomically
  const supabase = await createClient();
  const { data: numData, error: numErr } = await supabase.rpc('next_doc_number', {
    org: input.organization_id,
    dtype: 'invoice',
  });
  if (numErr || !numData) {
    return { error: 'Could not generate invoice number' };
  }

  // 7. Insert (RLS enforces org membership again — defense in depth)
  const { data: invoice, error: insErr } = await supabase
    .from('invoices')
    .insert({
      organization_id: input.organization_id,
      property_id: inv.property_id,
      tenant_id: inv.tenant_id,
      customer_name: inv.customer_name,
      invoice_number: numData,
      invoice_date: inv.invoice_date,
      due_date: inv.due_date,
      payment_terms: inv.payment_terms,
      salesperson: inv.salesperson,
      subject: inv.subject,
      customer_notes: inv.customer_notes,
      terms_conditions: inv.terms_conditions,
      shipping: inv.shipping,
      adjustment: inv.adjustment,
      subtotal,
      tax_total: taxTotal,
      total,
      created_by: user.id,
    })
    .select('id, invoice_number')
    .single();

  if (insErr || !invoice) {
    return { error: insErr?.message ?? 'Could not create invoice' };
  }

  // 8. Insert lines
  const lineRows = lines.map((l, i) => ({
    organization_id: input.organization_id,
    doc_type: 'invoice' as const,
    doc_id: invoice.id,
    sort_order: i,
    item_name: l.item_name,
    description: l.description,
    account: l.account,
    quantity: l.quantity,
    rate: l.rate,
    discount_pct: l.discount_pct,
    tax_pct: l.tax_pct,
    amount: l.total,
    period_label: l.period_label,
    unit_id: l.unit_id,
  }));

  const { error: lineErr } = await supabase.from('document_lines').insert(lineRows);
  if (lineErr) {
    // Compensating delete — keeps DB consistent if lines fail
    const admin = createAdminClient();
    await admin.from('invoices').delete().eq('id', invoice.id);
    return { error: 'Could not create invoice lines' };
  }

  // 9. Audit
  await audit({
    organizationId: input.organization_id,
    actorId: user.id,
    action: 'invoice.created',
    resourceType: 'invoice',
    resourceId: invoice.id,
    changes: { invoice_number: invoice.invoice_number, total },
  });

  revalidatePath('/invoices');
  return { ok: true, id: invoice.id, invoice_number: invoice.invoice_number };
}

export async function deleteInvoice(input: { organization_id: string; invoice_id: string }) {
  const user = await requireUser();
  await requireRole(input.organization_id, 'admin');
  await rateLimit(writeLimiter, `invoice-delete:${user.id}`);

  const supabase = await createClient();
  const { error } = await supabase.from('invoices').delete().eq('id', input.invoice_id);
  if (error) return { error: error.message };

  await audit({
    organizationId: input.organization_id,
    actorId: user.id,
    action: 'invoice.deleted',
    resourceType: 'invoice',
    resourceId: input.invoice_id,
  });

  revalidatePath('/invoices');
  return { ok: true };
}
