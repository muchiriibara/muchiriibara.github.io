import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { formatKES } from '@/lib/security/money';

export default async function InvoicesPage() {
  const supabase = await createClient();
  const { data: invoices, error } = await supabase
    .from('invoices')
    .select('id, invoice_number, customer_name, invoice_date, due_date, total, balance_due, status')
    .order('invoice_date', { ascending: false })
    .limit(100);

  if (error) {
    return <div className="p-8 text-red-400">Error loading invoices.</div>;
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Invoices</h1>
        <Link
          href="/invoices/new"
          className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-black hover:bg-emerald-400"
        >
          + New Invoice
        </Link>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-zinc-900 text-left text-xs uppercase text-zinc-500">
            <tr>
              <th className="px-4 py-3">Invoice #</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Due</th>
              <th className="px-4 py-3 text-right">Total</th>
              <th className="px-4 py-3 text-right">Balance</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {invoices?.length ? (
              invoices.map((i) => (
                <tr key={i.id} className="border-t border-zinc-800 hover:bg-zinc-800/30">
                  <td className="px-4 py-2 font-mono text-xs text-emerald-400">{i.invoice_number}</td>
                  <td className="px-4 py-2">{i.customer_name}</td>
                  <td className="px-4 py-2">{i.invoice_date}</td>
                  <td className="px-4 py-2">{i.due_date}</td>
                  <td className="px-4 py-2 text-right">{formatKES(i.total)}</td>
                  <td className="px-4 py-2 text-right">{formatKES(i.balance_due ?? 0)}</td>
                  <td className="px-4 py-2">
                    <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-xs">{i.status}</span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-zinc-500">
                  No invoices yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
