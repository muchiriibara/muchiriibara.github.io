import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const admin = createAdminClient();
    const { error } = await admin.from('organizations').select('id', { head: true, count: 'exact' });
    if (error) throw error;
    return NextResponse.json({ status: 'ok', timestamp: new Date().toISOString() });
  } catch (err) {
    return NextResponse.json(
      { status: 'degraded', error: err instanceof Error ? err.message : 'unknown' },
      { status: 503 },
    );
  }
}
