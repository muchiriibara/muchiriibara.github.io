// =====================================================================
// M-Pesa Daraja callback handler (STK push confirmation)
// =====================================================================
// Daraja posts here when a customer completes/declines an STK prompt.
// Validate the payload structure carefully — never trust callback data
// blindly. Match by CheckoutRequestID to your initiating record.
// Optionally allowlist Safaricom's IP ranges (publish list varies; check
// developer.safaricom.co.ke for current ranges).
// =====================================================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const callbackSchema = z.object({
  Body: z.object({
    stkCallback: z.object({
      MerchantRequestID: z.string(),
      CheckoutRequestID: z.string(),
      ResultCode: z.number(),
      ResultDesc: z.string(),
      CallbackMetadata: z
        .object({
          Item: z.array(z.object({ Name: z.string(), Value: z.any().optional() })),
        })
        .optional(),
    }),
  }),
});

export async function POST(req: NextRequest) {
  // TODO: enable IP allowlist when going live
  // const ip = (req.headers.get('x-forwarded-for') ?? '').split(',')[0]?.trim();
  // if (!SAFARICOM_IPS.includes(ip)) return NextResponse.json({}, { status: 403 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const parsed = callbackSchema.safeParse(body);
  if (!parsed.success) {
    console.error('M-Pesa callback shape unexpected:', parsed.error);
    // Daraja expects 200 even on errors, otherwise it retries
    return NextResponse.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  }

  const cb = parsed.data.Body.stkCallback;
  const admin = createAdminClient();

  // Look up the initiating record (you'd have created this when calling STK push)
  // For now, log and acknowledge.
  console.log('M-Pesa STK result:', {
    checkoutId: cb.CheckoutRequestID,
    code: cb.ResultCode,
    desc: cb.ResultDesc,
  });

  // Daraja always wants a 200
  return NextResponse.json({ ResultCode: 0, ResultDesc: 'Accepted' });
}
