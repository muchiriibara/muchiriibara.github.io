// =====================================================================
// Stripe webhook
// =====================================================================
// Webhooks are PUBLIC URLs — anyone on the internet can POST to them.
// Signature verification is the ONLY thing preventing forged requests.
// Never skip the verification step.
// =====================================================================

import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { createAdminClient } from '@/lib/supabase/admin';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-09-30.acacia' as any,
});

export const runtime = 'nodejs'; // Stripe lib needs node, not edge
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'No signature' }, { status: 400 });
  }

  const body = await req.text();
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!,
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const admin = createAdminClient();

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const s = event.data.object as Stripe.Checkout.Session;
        const orgId = s.metadata?.organization_id;
        if (!orgId) break;
        await admin
          .from('organizations')
          .update({
            stripe_customer_id: s.customer as string,
            stripe_subscription_id: s.subscription as string,
            subscription_status: 'active',
          })
          .eq('id', orgId);
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        const status =
          event.type === 'customer.subscription.deleted'
            ? 'canceled'
            : (sub.status as any);
        await admin
          .from('organizations')
          .update({ subscription_status: status })
          .eq('stripe_subscription_id', sub.id);
        break;
      }
      case 'invoice.payment_failed': {
        const inv = event.data.object as Stripe.Invoice;
        await admin
          .from('organizations')
          .update({ subscription_status: 'past_due' })
          .eq('stripe_customer_id', inv.customer as string);
        break;
      }
    }
  } catch (err) {
    console.error('Webhook handler error:', err);
    return NextResponse.json({ error: 'Handler failed' }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
