import Link from 'next/link';
import { signInAction } from '../actions';

export default function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; signedup?: string; error?: string }>;
}) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight">
            Prop<span className="text-emerald-400">Books</span>
          </h1>
          <p className="mt-2 text-sm text-zinc-400">Sign in to your workspace</p>
        </div>

        <form
          action={signInAction}
          className="space-y-4 rounded-2xl border border-zinc-800 bg-zinc-900/50 p-8 backdrop-blur"
        >
          <div>
            <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wide text-zinc-400">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              maxLength={254}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-800 px-4 py-2.5 text-sm focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-xs font-semibold uppercase tracking-wide text-zinc-400">
              Password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              minLength={8}
              maxLength={128}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-800 px-4 py-2.5 text-sm focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-emerald-500 py-2.5 text-sm font-semibold text-black hover:bg-emerald-400"
          >
            Sign In
          </button>

          <div className="text-center text-xs text-zinc-500">
            New here?{' '}
            <Link href="/signup" className="text-emerald-400 hover:underline">
              Create an account
            </Link>
          </div>
        </form>

        <p className="mt-8 text-center text-xs text-zinc-600">
          © 2026 PropBooks · Built &amp; maintained by Lucent Aura
        </p>
      </div>
    </div>
  );
}
