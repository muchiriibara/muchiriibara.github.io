import Link from 'next/link';
import { signUpAction } from '../actions';

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold">
            Prop<span className="text-emerald-400">Books</span>
          </h1>
          <p className="mt-2 text-sm text-zinc-400">Start your 14-day trial</p>
        </div>

        <form
          action={signUpAction}
          className="space-y-4 rounded-2xl border border-zinc-800 bg-zinc-900/50 p-8"
        >
          <Field name="full_name" label="Your name" required maxLength={100} />
          <Field name="organization_name" label="Company / agency name" required maxLength={100} />
          <Field name="email" label="Work email" type="email" required maxLength={254} />
          <Field
            name="password"
            label="Password (min 12 chars, mixed case, digit, symbol)"
            type="password"
            required
            minLength={12}
            maxLength={128}
          />
          <button
            type="submit"
            className="w-full rounded-lg bg-emerald-500 py-2.5 text-sm font-semibold text-black hover:bg-emerald-400"
          >
            Create account
          </button>
          <div className="text-center text-xs text-zinc-500">
            Already have one?{' '}
            <Link href="/login" className="text-emerald-400 hover:underline">
              Sign in
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field(props: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  const { label, ...rest } = props;
  return (
    <div>
      <label htmlFor={rest.name} className="block text-xs font-semibold uppercase tracking-wide text-zinc-400">
        {label}
      </label>
      <input
        id={rest.name}
        {...rest}
        className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-800 px-4 py-2.5 text-sm focus:border-emerald-500 focus:outline-none"
      />
    </div>
  );
}
