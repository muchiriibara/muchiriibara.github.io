'use server';

import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { createClient } from '@/lib/supabase/server';
import { signInSchema, signUpSchema } from '@/lib/validation/schemas';
import { rateLimit, signInLimiter, signUpLimiter } from '@/lib/security/ratelimit';
import { createAdminClient } from '@/lib/supabase/admin';

function getIp() {
  return headers()
    .then((h) => (h.get('x-forwarded-for') ?? 'unknown').split(',')[0]?.trim() || 'unknown');
}

export async function signInAction(formData: FormData): Promise<{ error?: string }> {
  // 1. Validate
  const parsed = signInSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
  });
  if (!parsed.success) {
    return { error: 'Invalid email or password format' };
  }

  // 2. Rate limit
  try {
    const ip = await getIp();
    await rateLimit(signInLimiter, `${ip}:${parsed.data.email}`);
  } catch {
    return { error: 'Too many attempts. Please wait a minute.' };
  }

  // 3. Authenticate
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);

  if (error) {
    // Generic message — don't reveal whether email exists
    return { error: 'Invalid credentials' };
  }

  redirect('/dashboard');
}

export async function signUpAction(formData: FormData): Promise<{ error?: string }> {
  const parsed = signUpSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
    full_name: formData.get('full_name'),
    organization_name: formData.get('organization_name'),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? 'Invalid input' };
  }

  try {
    const ip = await getIp();
    await rateLimit(signUpLimiter, ip);
  } catch {
    return { error: 'Too many signups from your network. Try again later.' };
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { full_name: parsed.data.full_name },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/callback`,
    },
  });

  if (error || !data.user) {
    return { error: error?.message ?? 'Could not create account' };
  }

  // Create org + owner membership atomically (uses service role to bypass RLS)
  const admin = createAdminClient();
  const slug =
    parsed.data.organization_name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 50) +
    '-' +
    Math.random().toString(36).slice(2, 6);

  const { data: org, error: orgErr } = await admin
    .from('organizations')
    .insert({ name: parsed.data.organization_name, slug })
    .select('id')
    .single();
  if (orgErr || !org) return { error: 'Could not create organization' };

  await admin.from('memberships').insert({
    user_id: data.user.id,
    organization_id: org.id,
    role: 'owner',
    accepted_at: new Date().toISOString(),
  });

  redirect('/login?signedup=1');
}

export async function signOutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect('/login');
}
